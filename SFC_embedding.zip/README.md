# Using Deep Reinforcement Learning method and Attention model to solve the SFC embedding. 
## This code is the model with 32-dimension input (24,8)mean(network link resource, each node's VNF function type).


+ To test the model, use the load_all_rewards in Post_process dir.
+ To train the model, run train_motsp_transfer.py

    

### A lot codes are inherited from https://github.com/mveres01/pytorch-drl4vrp
